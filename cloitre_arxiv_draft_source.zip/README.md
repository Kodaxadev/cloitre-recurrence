# arXiv draft package

## Working title

**The Eventual-Increment Spectrum of Cloitre's Recurrence Is Not Surjective**

This package is the first focused paper extracted from the broader `cloitre-recurrence` repository. It contains only the completed finite-start theorem and the independently certified proof that 5 and 7 are the smallest omitted eventual increments.

## Source basis

Repository: `Kodaxadev/cloitre-recurrence`  
Drafted from commit: `7ccda13f112f3768a35d28759891aaa0689e3c77`

Primary source files used:

- `partial-proofs.md`
- `manuscript/01-foundations-and-spectrum.md`
- `supplement/02-certificates.md`
- `supplement/03-reproduction.md`
- `certificates/spectrum_m259.csv`

## Build

Run:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

No bibliography tool is required; references are embedded in `main.tex`.

## Reproduce the finite certificate

From the repository root:

```powershell
python independent\verify_small_spectrum.py
Get-FileHash -Algorithm SHA256 certificates\spectrum_m259.csv
```

Expected SHA-256:

```text
66a06cff15735c4a3caf98575f29afbcd881fbef06334616fbc3bc772b7ab084
```

## Current status

- The finite-start theorem is written as a complete symbolic proof.
- The 259-row certificate is independently regenerated using arbitrary-precision literal recurrence dynamics.
- Universal stabilization remains open.
- Theorem 18 and the nonsurjectivity theorem are not formalized in Lean.
- Human specialist review remains pending.

## Editorial next steps

1. Obtain a line-by-line human mathematical review of the finite-start theorem.
2. Confirm historical attribution and bibliography wording.
3. Add author contact details and ORCID, if applicable.
4. Archive an immutable release containing the manuscript source, verifier, certificate, and hashes.
5. Compile with arXiv's TeX environment before submission.
